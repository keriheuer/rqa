import numpy as np
# from scipy.stats import norm # import doesn't work
from random import gauss


def sine(freq, amp=1, phi=0):
    fs = 500    # (integer) sampling rate
    f = freq       # (integer) fundamental frequency of the sinusoid
    t = 1    # (integer) duration of the time series

    time = np.linspace(0, t, t * fs) # total number of samples
    signal = np.sin(2 * np.pi * f * time + phi) # for sin(B*t) the period is 2*pi/B

    return signal*amp

def cosine(freq, amp=1, phi=0):

    fs = 500    # (integer) sampling rate
    f = freq       # (integer) fundamental frequency of the sinusoid
    t = 1      # (integer) duration of the time series

    time = np.linspace(0, t, t * fs) 
    signal = np.cos(2 * np.pi * f * time + phi) # for sin(B*t) the period is 2*pi/B
    return signal

# def uncorrelated_uniform_noise(self, duration=0.1, framerate=7000, show=False):
#     """ Generates time series for uncorrelated uniform noise.
#     """

#     signal = UncorrelatedUniformNoise()
#     wave = signal.make_wave(duration=400, framerate=framerate) #11025)

#     segment = wave.segment(duration=0.1)

#     if show == True:
#         segment.plot(linewidth=1)
#         decorate(xlabel='Time (s)', ylabel='Amplitude')

#     return segment

def white_noise(duration=1000, mean=0.0, std=1.0):
    """
    Generates time series for uncorrelated uniform (Gaussian) noise.

    :param duration: integer, length of time series
    :param mean: float, average value of noise
    :param std: float, standard deviation of the noise
    """

    white_noise = np.array([gauss(mean, std) for i in range(duration)])
    return white_noise

# methods to generate Brownian motion
#     REF: https://towardsdatascience.com/brownian-motion-with-python-9083ebc46ff0
def gen_random_walk(x0=0, n_step=100):
    """
    Generate motion by random walk

    Arguments:
        n_step: Number of steps

    Returns:
        A NumPy array with `n_steps` points
    """
    # Warning about the small number of steps
    if n_step < 30:
        print("WARNING! The number of steps is small. It may not generate a good stochastic process sequence!")

    w = np.ones(n_step)*x0

    for i in range(1,n_step):
        # Sampling from the Normal distribution with probability 1/2
        yi = np.random.choice([1,-1])
        # Weiner process
        w[i] = w[i-1]+(yi/np.sqrt(n_step))

    return w

def gen_normal(x0=0, n_step=100):
    """
    Generate motion by drawing from the Normal distribution

    Arguments:
        n_step: Number of steps

    Returns:
        A NumPy array with `n_steps` points
    """
    if n_step < 30:
        print("WARNING! The number of steps is small. It may not generate a good stochastic process sequence!")

    w = np.ones(n_step)*x0

    for i in range(1,n_step):
        # Sampling from the Normal distribution
        yi = np.random.normal()
        # Weiner process
        w[i] = w[i-1]+(yi/np.sqrt(n_step))

    return w

def disrupted_brownian(N, M):
    """ Generates time series for disrupted Brownian motion.
    N = number of iterations to return
    M = number of points/random variates to use
    """

    r = norm.rvs(size=M)
    x = np.empty((M))

    for i in np.arange(M-1):
        x[i+1] = x[i] + (2*r[i])

    disrupted = x[1:N]

    return disrupted

def rossler(a,b,c,t,tf,h):

    def derivative(r,t):
        x = r[0]
        y = r[1]
        z = r[2]
        return np.array([- y - z, x + a * y, b + z * (x - c)])

    time = np.array([]) #Empty time array to fill for the x-axis
    x = np.array([]) #Empty array for x values
    y = np.array([]) #Empty array for y values
    z = np.array([]) #Empty array for z values
    r = np.array([1.0, 1.0, 1.0]) #Initial conditions array

    while (t <= tf ):
        time = np.append(time, t)
        z = np.append(z, r[2])
        y = np.append(y, r[1])
        x = np.append(x, r[0])

        k1 = h*derivative(r,t)
        k2 = h*derivative(r+k1/2,t+h/2)
        k3 = h*derivative(r+k2/2,t+h/2)
        k4 = h*derivative(r+k3,t+h)
        r += (k1+2*k2+2*k3+k4)/6
        t = t + h

    return time, x,y,z

def logistic_map(r,y,drift,N,M):
    """ Generates time series for logistic map.
        REF: https://www.r-bloggers.com/logistic-map-feigenbaum-diagram/

        r = bifurcation parameter
        x = initial value
        N = number of iterations
        M = number of iteration points to returns
    """
    

    x = np.zeros(N + 1)
    z = np.zeros(N + 1)
    x[0], z[0] = 0, y

    # loop over the steps and replace array values with calculations
    for i in range(N):
        z[i+1] = r * z[i] * (1 - z[i])
        x[i+1] = x[i] + 1

    # z = np.empty((N))
    # z[0] = x
    # for i in np.arange(N-1):
    #     z[i+1] = r * z[i] * (1 - z[i])
    #     x[i+1] = x[i] + 1

    # lm = z[N-M:N]

    # add linear trend if given
    lm = z + (drift * np.arange((len(z))))
    return lm

def henon(length=10000, x0=None, a=1.4, b=0.3, discard=500):
    """Generate time series using the Henon map.

    REF: https://github.com/manu-mannattil/nolitsa/blob/master/nolitsa/data.py

    Parameters
    ----------
    length : int, optional (default = 10000)
        Length of the time series to be generated.
    x0 : array, optional (default = random)
        Initial condition for the map.
    a : float, optional (default = 1.4)
        Constant a in the Henon map.
    b : float, optional (default = 0.3)
        Constant b in the Henon map.
    discard : int, optional (default = 500)
        Number of steps to discard in order to eliminate transients.

    Returns
    -------
    x : ndarray, shape (length, 2)
        Array containing points in phase space.
    """
    x = np.empty((length + discard, 2))

    if not x0:
        x[0] = (0.0, 0.9) + 0.01 * (-1 + 2 * np.random.random(2))
    else:
        x[0] = x0

    for i in range(1, length + discard):
        x[i] = (1 - a * x[i - 1][0] ** 2 + b * x[i - 1][1], x[i - 1][0])

    return x[discard:]

def normalize(ts):
    '''
    Normalize a time series to have zero mean and unit standard deviation.
    Inputs:
        self.ts : input time series (numpy array or list)
    Outputs:
        z : normalized time series (numpy array)
    '''
    # if type(self.ts) is list:
    #     self.ts = np.array(self.ts)
    # if type(self.ts) is not np.ndarray:
    #     print('input time series must by a numpy array or list. exiting.')
    #     return 

    # normalize time series 
    return (ts - np.mean(ts)) / np.std(ts)

class RecurrencePlot:
    
    def calculate_lacunarity(R, max_box_size):
        T = R.shape[0]
        lacunarities = []

        for w in range(2, max_box_size + 1):
            N = int(T / w)
            M = np.zeros((N, N))

            # Count the black pixels (recurrences) in each box
            for i in range(N):
                for j in range(N):
                    M[i, j] = np.sum(R[i*w:(i+1)*w, j*w:(j+1)*w])
            
            # Calculate moments and lacunarity for this box size
            M_flattened = M.flatten()
            Z1 = np.mean(M_flattened)
            Z2 = np.mean(M_flattened ** 2)
            lacunarity = (Z2 / Z1**2) - 1
            lacunarities.append(lacunarity)
        
        return lacunarities

# # Example usage:
# R = np.random.randint(2, size=(100, 100))  # Random binary matrix as an example RP
# max_box_size = 10
# lacunarities = calculate_lacunarity(R, max_box_size)
# print(lacunarities)